const { JsonDatabase } = require("wio.db")

const channelsLogs = new JsonDatabase({ databasePath: "./database/channels" })

module.exports = {
    channelsLogs
}