const { Client, GatewayIntentBits, Collection, Partials } = require("discord.js");
console.clear();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,               // Necessário para servidores
    GatewayIntentBits.GuildMessages,        // Mensagens em servidores
    GatewayIntentBits.GuildMessageReactions,// Reações a mensagens
    // GatewayIntentBits.GuildMembers,      // INTENT PRIVILEGIADA (descomente se necessário)
    // GatewayIntentBits.MessageContent     // INTENT PRIVILEGIADA (descomente se necessário)
  ],
  partials: [] // Só adicione se precisar de funcionalidades específicas
});

module.exports = client;
client.slashCommands = new Collection();
const { token, port } = require("./config.json");
client.login(token);

const evento = require("./handler/Events");
evento.run(client);
require("./handler/index")(client);

const express = require("express");
const app = express();
app.use(express.json());

const callback = require("./Routers/callback");
app.use("/", callback);

const portHost = process.env.PORT ? Number(process.env.PORT) : port;
app.listen(portHost, () => {
  console.log(`- API Inicializada com sucesso!`);
});