const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const Discord = require("discord.js");
const config = require("../../config.json");


module.exports = {
  name: "interactionCreate",
  run: async (interaction, client) => {

    if (interaction.isButton() && interaction.customId === "notify") {
      const role = interaction.guild.roles.cache.get(config.role_member_notify)
      const member = interaction.guild.members.cache.get(interaction.user.id);

      if (!role) {
        await interaction.reply({ content: `❌ | Espere um pouco, o cargo de notify ainda não foi setado...`, ephemeral: true });
        return;
      }

      if (member.roles.cache.has(role.id)) {
        await member.roles.remove(role);
        await interaction.reply({ content: '✅ | Cargo de notificação removido com sucesso!', ephemeral: true });
      } else {
        await member.roles.add(role);
        await interaction.reply({ content: '✅ | Cargo de notificação adicionado com sucesso!', ephemeral: true });
      }
    }
  }
}