const { ActivityType } = require("discord.js");
const axios = require("axios")


module.exports = {
    name:"ready",
    run:async(client) => {console.clear();
        console.log("\n");
        console.log(`\x1b[32m[LIGADO]\x1b[0m - ${client.user.tag}`);
        console.log(`\x1b[32m[SERVERS]\x1b[0m - Atualmente em ${client.guilds.cache.size} servidores.`);
        console.log(`\x1b[32m[MEMBERS]\x1b[0m - Contendo ${client.users.cache.size} usuários.\n\n`);
       
       
       let status = [
            {
                name: "九",
                type: ActivityType.Streaming,
                url: 'https://www.twitch.tv/discord',
            },
        ];

//        function clearConsole() {
//            console.clear();
//        }

//        setInterval(clearConsole, 10000);

        client.user.setActivity(status[0].name, {
            type: status[0].type,
            url: status[0].url,
        });
       
        
                // Altera a descrição do bot para a oficial
        let description = "ᐉ https://discord.gg/2vZpdcZMsm\n";
        try {
            await axios.patch(`https://discord.com/api/v10/applications/${client.user.id}`, {
                description: description
            }, {
                headers: {
                    "Authorization": `Bot ${client.token}`,
                    "Content-Type": 'application/json',
                }
            });
        } catch (error) {
            console.error('Erro ao atualizar descrição do bot:', error);
        }


    }
        
}