const { InteractionType } = require("discord.js");
const { owner } = require("../../config.json");

module.exports = {
    name:"interactionCreate",
    run:async(interaction, client) => {

        if(interaction.type === InteractionType.ApplicationCommand){

            const cmd = client.slashCommands.get(interaction.commandName);
      
            if (!cmd) return;
      
            if(interaction.user.id !== owner) return interaction.reply({
                content:`Você não tem permissão de usar este comando.`,
                ephemeral: true
            });

            cmd.run(client, interaction);
         };
          

    }
    

}