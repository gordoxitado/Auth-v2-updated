const { ApplicationCommand, EmbedBuilder, ApplicationCommandType, ModalBuilder, TextInputBuilder, ActionRowBuilder, ButtonBuilder, MessageEmbed } = require("discord.js");
const fs = require('fs').promises;
const fs1 = require('fs');
const fetch = require('node-fetch');
const config = require("../../config.json");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({databasePath:"./database/postagem.json"});
const channelsLogs = new JsonDatabase({ databasePath: "./database/channels.json" })
const cooldowns = new Map();
const path = require("path");
const moment = require("moment")

module.exports = {
    name:"interactionCreate",
    run: async(interaction, client) => {

        if (interaction.isButton() && interaction.customId === "abrirModalUp") {

            const modal = new ModalBuilder()
            .setCustomId(`upload_modal`)
            .setTitle("🔎 | Upload de Key");
    
            const text = new TextInputBuilder()
            .setStyle(2)
            .setMaxLength(2045)
            .setCustomId("content")
            .setLabel("Mensagem")
            .setPlaceholder("Mensagem que ficará em cima do arquivo")
            .setRequired(false);
    
            const text2 = new TextInputBuilder()
            .setStyle(1)
            .setMaxLength(200)
            .setCustomId("key")
            .setLabel("Coloque a key:")
            .setPlaceholder("Coloque a KEY da source")
            .setRequired(false);
    
            const text3 = new TextInputBuilder()
            .setStyle(1)
            .setMaxLength(200)
            .setCustomId("desc")
            .setLabel("Coloque a descrição da key")
            .setPlaceholder("Ex: Bot vendas com sistema restoque")
            .setRequired(false);
    
            modal.addComponents(new ActionRowBuilder().addComponents(text));
            modal.addComponents(new ActionRowBuilder().addComponents(text2));
            modal.addComponents(new ActionRowBuilder().addComponents(text3));
            
            return interaction.showModal(modal);

        }
        
        const customId = interaction.customId;
        if(!customId) return;
        if(customId === "upload_modal") {
            const content = interaction.fields.getTextInputValue("content");
            const plano = "geral";
            const key = interaction.fields.getTextInputValue("key");
            const desc = interaction.fields.getTextInputValue("desc");
            if(plano !== "geral") return interaction.reply({content:`❌ | Escolha apenas **geral** para o plano.`, ephemeral:true});
            if(await db.get(key)) return interaction.reply({content:`🔎 | Já Existe uma key registrada com este nome.`, ephemeral:true});

            const msg = await interaction.reply({content:`🔎 | ${interaction.user} envie o arquivo que a pessoa irá receber após resgatar a key, se quiser parar apenas envie "parar"`});
            const filterMensagem = (msg) => msg.author.id === interaction.user.id;
            const collectorMensagem = interaction.channel.createMessageCollector({ filter: filterMensagem });

            collectorMensagem.on("collect", async (message) => {
                if(message.content === "parar") {
                    collectorMensagem.stop();
                    if(msg) msg.delete();
                    interaction.channel.send({content:`✅ | Cancelado com sucesso!`}).then((msg) => {
                        setTimeout(() => {
                            msg.delete();
                        }, 3000);
                    });
                    return;
                }
                const attachmentArray = Array.from(message.attachments.values());
                if (attachmentArray.length > 0) {
                    if(attachmentArray.length > 1) {
                        interaction.channel.send({content:`❌ | Coloque apenas 1 arquivo.`, ephemeral:true}).then((msg) => {
                            setTimeout(() => {
                                msg.delete();
                            }, 1200);
                        });
                        return;
                    }
                    const urlarchive = attachmentArray[0].url;
                    const attachName = attachmentArray[0].name;
                    const all = await db.all().filter(a => a.data.nomearquivo === attachName && a.data.plano === plano);
                    if(all.length > 0) {
                        await interaction.channel.send({
                            content:`❌ | Já Existe um Arquivo com este nome!`,
                            ephemeral:true
                        }).then((msg) => {
                            setTimeout(() => {
                                msg.delete();
                            }, 1200);
                        });
                        return;
                    }
                    const destinationPath = `./sources/${plano}/${attachName}`;

                    await download(urlarchive, destinationPath);
                    await db.set(`${key}`, {
                        plano: plano,
                        nomearquivo: attachName,
                        desc: desc,
                        mensagem: content,
                        postador: interaction.user.id
                        
                    });
                    if(msg) msg.delete();
                    interaction.channel.send({content:`✅ | Upload foi um sucesso! ${interaction.user}`, ephemeral:true});
                    collectorMensagem.stop();

                    const notifyMembers = config.role_member_notify
                    const timeKeySend = `<t:${Math.floor(moment().toDate().getTime() / 1000)}:f> (<t:${Math.floor(moment().toDate().getTime() / 1000)}:R>)`;


                    const embed = new EmbedBuilder()
                        .setTitle('## 🔧 | Nova Key Registrada')
                        .setDescription(`Uma nova key foi registrada por ${interaction.user}`)
                        .setColor('#FFFFFF') // Cor do embed, pode ser alterada conforme desejado
                        .addFields(
                          { name: `**🔎 Nome da Key**`, value: `\`${key}\``, inline: true },
                          { name: `**📋 Descrição**`, value: `\`${desc}\``, inline: true },
                          { name: `**👤 Poster**`, value: `${interaction.user} | \`${interaction.user.id}\``, inline: true },
                        )
                        
                    const channel = client.channels.cache.get(channelsLogs.get("channel_logs_public"));
                    if (channel) {
                        channel.send({
                            embeds: [embed],
                            components: [
                                new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder().setCustomId(`keyresgiterlogspublic1`).setLabel(`Nova key resgistrada`).setStyle(2).setDisabled(true)
                                )
                            ]
                        });
                    }

                } else {
                    interaction.channel.send({content:`❌ | Envie um arquivo!`, ephemeral:true}).then((msg) => {
                        setTimeout(() => {
                            msg.delete();
                        }, 1200);
                    })
                }

            })

        }

        if(customId.startsWith("resgatarkey_")) {
            const service = customId.split("_")[1];
            const modal = new ModalBuilder()
           .setCustomId(`${service}_resgatarmodal`)
           .setTitle("🔑 - Resgatar Source");

            const text = new TextInputBuilder()
           .setCustomId("text")
           .setStyle(1)
           .setRequired(true)
           .setPlaceholder("Coloque a Key aqui")
           .setLabel("Qual é a key?");

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }
        if(customId.endsWith("_resgatarmodal")) {
            const text = interaction.fields.getTextInputValue("text");
            const prod = await db.get(text);
            if(!prod) return interaction.reply({content:`❌ | Não existe nenhuma key com este nome!`, ephemeral:true});
            const sv = customId.split("_")[0];
            const destinationPath = `./sources/${prod.plano}/${prod.nomearquivo}`;
            const channel = interaction.client.channels.cache.get(channelsLogs.get("channel_logs_priv"));
            if(channel) {
                channel.send({content:`🍃 | O Usuario ${interaction.user} tentou coletar está key: \`${text}\``});
            }
            const now = Date.now();
            const cooldownAmount = 150000;
            
            if (cooldowns.has(interaction.user.id)) {
                const expirationTime = cooldowns.get(interaction.user.id) + cooldownAmount;
                const timeLeft = expirationTime - now;

                if (timeLeft > 0) {
                    const timeLeftSeconds = Math.ceil(timeLeft / 1000);
                    const timeLeftFormatted = `<t:${Math.floor(timeLeftSeconds + (now / 1000))}:f> (<t:${Math.floor(timeLeftSeconds + (now / 1000))}:R>)`;
                    interaction.reply({ content: `⏰ | Espere um pouco, você está em cooldown, seu cooldown acaba ${timeLeftFormatted}`, ephemeral: true })
                    if(channel) {
                        channel.send({content:`⏰ | O Usuario: ${interaction.user} está com cooldown de ${timeLeftFormatted}`})
                    }
                    return;
                }
            }
            cooldowns.set(interaction.user.id, now + cooldownAmount);
            await interaction.reply({content:`🔁 | Aguarde um momento....`, ephemeral:true});
            const data = fs1.readFileSync(destinationPath);
            const fileName = path.basename(destinationPath);
            interaction.editReply({
                    content: `${prod.mensagem}\n\n🔎 | Postador: <@${prod.postador}>\n👑 | Bot feito pelo Pedrin,
                    files: [{ attachment: data, name: fileName }]
                });
            }

        }

    }


async function download(url, destination) {
    const response = await fetch(url);
    const buffer = await response.buffer();
    await fs.writeFile(destination, buffer);
}