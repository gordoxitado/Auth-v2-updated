const { InteractionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require("discord.js");
const { owner, url } = require("../../config.json");

module.exports = {
    name:"interactionCreate",
    run:async(interaction, client) => {
        const { customId, user, guild } = interaction;
        if(!customId) return;
        if(!guild) return;
        if(customId === "enviarmensagem_modal") {
            const title = interaction.fields.getTextInputValue("title");
            const desc = interaction.fields.getTextInputValue("desc");
            const channel = guild.channels.cache.get(interaction.fields.getTextInputValue("channel"));
            if(!channel) return interaction.reply({content:`❌ **| Você ainda não colocou um id valido.**`, ephemeral: true });
            await interaction.reply({
                content:`🔁 **| Enviando mensagem..**`,
                ephemeral: true
            });
            await channel.send({
                embeds: [
                    new EmbedBuilder()
                    .setTitle(title)
                    .setDescription(desc)
                    .setColor("#00FFFF")
                ],
                components: [
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&response_type=code&redirect_uri=${url}/callback&scope=guilds+guilds.join+email+identify`)
                        .setLabel("Verificar")
                        .setStyle(5)
                    )
                ]
            });
            interaction.editReply({
                content:`✅ **| Mensagem enviada no canal: ${channel}**`
            });
        }
    }
}