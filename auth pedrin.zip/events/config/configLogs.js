const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
const Discord = require("discord.js");
const { channelsLogs } = require("../../database/index")


module.exports = {
  name: "interactionCreate",
  run: async (interaction, client) => {

    if (interaction.isChannelSelectMenu()) {
        if (interaction.customId === "channelLogsPublic") {
           
           channelsLogs.set(`channel_logs_public`, interaction.values[0])
           
           const select1 = new ActionRowBuilder()
           .addComponents(
               new ChannelSelectMenuBuilder()
               .setCustomId(`channelLogsPublic`)
               .setPlaceholder(`Clique aqui para selecionar o canal logs publicas`)
               .setMinValues(1)
               .setMaxValues(1)
               .setChannelTypes(ChannelType.GuildText)
           )
   
           const select2 = new ActionRowBuilder()
           .addComponents(
               new ChannelSelectMenuBuilder()
               .setCustomId(`channelLogsPrivate`)
               .setPlaceholder(`Clique aqui para selecionar o canal logs privadas`)
               .setMinValues(1)
               .setMaxValues(1)
               .setChannelTypes(ChannelType.GuildText)
           )
           
           await interaction.update({
            content: `- ${interaction.user}, Nos dois select menu abaixo você pode gerenciar as logs publicas e as logs privadas!\n- **Logs Publicas:** ${channelsLogs.get("channel_logs_public") != "" ? interaction.guild.channels.cache.get(channelsLogs.get("channel_logs_public")) : "\`Não definido ainda.\`"}\n- **Logs Privadas:** ${channelsLogs.get("channel_logs_priv") != "" ? interaction.guild.channels.cache.get(channelsLogs.get("channel_logs_priv")) : "\`Não definido ainda.\`"}\n\n> Selecione abaixo:`,
               components:[select1, select2]
           })
        }
    }

    if (interaction.isChannelSelectMenu()) {
      if (interaction.customId === "channelLogsPrivate") {
         
         channelsLogs.set(`channel_logs_priv`, interaction.values[0])
         
         const select1 = new ActionRowBuilder()
         .addComponents(
             new ChannelSelectMenuBuilder()
             .setCustomId(`channelLogsPublic`)
             .setPlaceholder(`Clique aqui para selecionar o canal logs publicas`)
             .setMinValues(1)
             .setMaxValues(1)
             .setChannelTypes(ChannelType.GuildText)
         )
 
         const select2 = new ActionRowBuilder()
         .addComponents(
             new ChannelSelectMenuBuilder()
             .setCustomId(`channelLogsPrivate`)
             .setPlaceholder(`Clique aqui para selecionar o canal logs privadas`)
             .setMinValues(1)
             .setMaxValues(1)
             .setChannelTypes(ChannelType.GuildText)
         )
         
         await interaction.update({
             content: `- ${interaction.user}, Nos dois select menu abaixo você pode gerenciar as logs publicas e as logs privadas!\n- **Logs Publicas:** ${channelsLogs.get("channel_logs_public") != "" ? interaction.guild.channels.cache.get(channelsLogs.get("channel_logs_public")) : "\`Não definido ainda.\`"}\n- **Logs Privadas:** ${channelsLogs.get("channel_logs_priv") != "" ? interaction.guild.channels.cache.get(channelsLogs.get("channel_logs_priv")) : "\`Não definido ainda.\`"}\n\n> Selecione abaixo:`,
             components:[select1, select2]
         })
      }
  }

  }
}