const Discord = require("discord.js")

module.exports = {
  name: "nuke",
  description: "[🤖] Apague e crie um novo canal",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
        name: "channel",
        description: "Qual será o canal que ira ser nukado?",
        type: Discord.ApplicationCommandOptionType.Channel,
        required: false,
    }
],

  run: async (client, interaction) => {

    if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageMessages)) {
        interaction.reply({ content: `Você não possui permissão para utilizar este comando.`, ephemeral: true })
        return;
    } 

    const channel = interaction.options.getChannel("channel") || interaction.channel
    
    const confirmEmbed = new Discord.EmbedBuilder()
      .setColor(0xFF0000)
      .setTitle("Tem certeza?")
      .setDescription("Continuar irá excluir permanentemente todas as mensagens do ⁠#" + channel.name + ". Esta ação não pode ser desfeita.");

    const confirmButtons = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('confirm_yes')
          .setLabel('Sim')
          .setStyle(Discord.ButtonStyle.Success),
        new Discord.ButtonBuilder()
          .setCustomId('confirm_no')
          .setLabel('Não')
          .setStyle(Discord.ButtonStyle.Danger)
      );

    const message = await interaction.reply({ embeds: [confirmEmbed], components: [confirmButtons], fetchReply: true });

    const filter = (interaction) => interaction.user.id === interaction.user.id;
    const collector = message.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (i) => {
      if (i.customId === 'confirm_yes') {
        collector.stop();
        channel.clone().then((chan) => {
          channel.delete()
          chan.send(`Nuked by \`${interaction.user.username}\``)
        })
      } else if (i.customId === 'confirm_no') {
        collector.stop();
        await interaction.editReply({ embeds: [confirmEmbed.setDescription('Nuke cancelado.')], components: [] });
      }
    });

    collector.on('end', (collected, reason) => {
      if (reason === 'time') {
        interaction.editReply({ embeds: [confirmEmbed.setDescription('Tempo limite para confirmação esgotado.')], components: [] });
      }
    });

  }
}
