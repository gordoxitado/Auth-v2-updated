const { ApplicationCommandType } = require("discord.js");


module.exports = {
    name:"ping", 
    description:"[🔧] Veja o PING do bot!", 
    type: ApplicationCommandType.ChatInput,
    run: async(client, interaction) => { 
        await interaction.deferReply({ ephemeral: true });

        interaction.followUp({ 
            content:`\`🟢\` Olá ${interaction.user}, atualmente meu ping está em \`${client.ws.ping} ms\``
        })

    }
}