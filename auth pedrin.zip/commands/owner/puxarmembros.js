const { ApplicationCommandType } = require("discord.js");
const { canal_logs, cargo_verificado, client_secret, url, owner } = require("../../config.json");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({ databasePath:"./database/users.json" });
const axios = require("axios");



module.exports = {
    name:"puxar_membros",
    description:"[🔧] Puxe todos os membros para este servidor!",
    type: ApplicationCommandType.ChatInput,
    run: async(client, interaction) => {
        const all = await db.all();
        if(all.length <= 0) return interaction.reply({content:`😢 **| Você não tem nenhum membro verificado...**`, ephemeral: true});
        await interaction.reply({
            content:`✅ **| Todos os membros que estão verificados será puxado em breve!**`,
            ephemeral: true
        });
        for(const se of all) {
            try {
                const token = se.data;
                const userid = se.ID;
                const headers = {
                    'Content-Type': 'application/x-www-form-urlencoded'
                };
                const data = {
                    client_id: client.user.id,
                    client_secret: client_secret,
                    grant_type: "refresh_token",
                    refresh_token: token,
                };
        
                const response = await axios.post("https://discord.com/api/oauth2/token", data, {
                    headers: headers,
                });
                const { access_token, refresh_token } = response.data;

                const body = { access_token }
                await axios.put(`https://discord.com/api/guilds/${interaction.guild.id}/members/${userid}`, JSON.stringify(body), {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bot ${client.token}`,
                    },
                }).catch((err) => {});
                await db.set(`${userid}`, refresh_token);
            } catch(err) {
                
            }
        }
    }
}