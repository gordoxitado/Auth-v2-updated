const { ApplicationCommandType } = require("discord.js");
const { canal_logs, cargo_verificado, client_secret, url, owner } = require("../../config.json");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({ databasePath:"./database/users.json" });

module.exports = {
    name:"info_auth",
    description:"[🔧] Veja as informações do seu auth",
    type: ApplicationCommandType.ChatInput,
    run: async(client, interaction) => {
        interaction.reply({
            content:`- Dono do Auth\n - <@${owner}>\n- REDIRECT URI:\n - ${url}/callback\n- Cargo de Verificado: \n - <@&${cargo_verificado}>\n- Canal de Logs:\n - <#${canal_logs}>\n- Total de Verificados: ${await db.all().length}`,
            ephemeral: true
        });
    }
}