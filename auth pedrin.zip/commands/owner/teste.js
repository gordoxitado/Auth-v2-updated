const { ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");

module.exports = {
    name: "painel_auth",
    description: "[🔌] Painel Authentication",
    type: ApplicationCommandType.ChatInput,
    run: async (client, interaction) => {
        await interaction.reply({ content: `<a:1236149701401907210:1241812178487742464> | Enviando painel verify...`, ephemeral: true });

        const fileImage = 'https://media.discordapp.net/attachments/1257780565369684009/1257797229910167622/caac19f716856034.png?ex=6685b674&is=668464f4&hm=18021f65054eca2550957bdafc1f46b0b3aa31ab75575e30811dbdf2bb562b50&=&format=webp&quality=lossless&width=687&height=386';
        const verifyUrl = 'https://discord.com/oauth2/authorize?client_id=1257798164174602270&response_type=code&redirect_uri=http://localhost:8080/callback&scope=guilds+guilds.join+email+identify'; // Seu URL de verificação aqui! De preferência RestoreCord

        const components = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setURL(verifyUrl).setLabel(`Verificar-se`).setEmoji("<:1248300403452280884:1248760691289096213>").setStyle(5),
                new ButtonBuilder().setCustomId(`duvidaVerify`).setLabel(`Por que verificar?`).setEmoji("<:1223682742609514586:1241812203892637728>").setStyle(2)
            );

        const msg = await interaction.channel.send({
            content: `# <:1249045997343211592:1255331903783960627>  Verifique-se

**Como posso ter certeza de que não irão vender membros?**

- Bom, infelizmente não temos como garantir isso, por isso eu peço que possamos ter uma confiança mútua entre nós **Owners** com vocês **Membros**/**Clientes**.`,
            files: [fileImage],
            components: [components]
        });

        await interaction.followUp({ content: `<:1236149726009888809:1241812186469503026> | Painel verify enviado com sucesso!`, ephemeral: true });

        const collectorFilter = (i) => i.user.id === interaction.user.id;
        const collectorConfig = msg.createMessageComponentCollector({
            filter: collectorFilter,
            time: 60000 // Define um tempo limite para o coletor, caso contrário ele ficará ativo indefinidamente
        });

        collectorConfig.on("collect", async (iManage) => {
            if (iManage.customId === `duvidaVerify`) {
                const components2 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setURL(verifyUrl).setLabel(`Verificar-se`).setStyle(5)
                    );

                await iManage.reply({
                    content: `- Sua verificação é essencial para reforçar a segurança do servidor e manter nossa comunidade protegida.\n- Além disso, em casos raros de queda do servidor, a verificação nos permite trazê-lo de volta rapidamente para que você não perca nenhum momento importante.\n- Isso também ajuda a evitar contas falsas.`,
                    components: [components2],
                    ephemeral: true
                });
            }
        });

        collectorConfig.on("end", collected => {
            console.log(`Collected ${collected.size} interactions.`);
        });
    }
};
