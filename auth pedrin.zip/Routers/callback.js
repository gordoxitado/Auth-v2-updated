const { JsonDatabase } = require("wio.db");
const { Router } = require("express");
const { EmbedBuilder } = require("discord.js");
const requestIp = require('request-ip');
const geoip = require('geoip-lite');
const axios = require("axios");
const { canal_logs, cargo_verificado, client_secret, client_id, redirect_uri } = require("../config.json");

const db = new JsonDatabase({ databasePath: "./database/users.json" });
const app = Router();

app.get("/callback", async (req, res) => {
    try {
        const client = require("..");
        const { code } = req.query;

        // Verificação básica do código
        if (!code || typeof code !== 'string') {
            return res.status(400).send("Código de autorização inválido ou ausente");
        }

        // Obter informações do cliente
        const ip = requestIp.getClientIp(req) || 'IP não detectado';
        const location = geoip.lookup(ip);
        let locationInfo = "Localização não disponível";
        if (location) {
            locationInfo = `${location.city || 'Cidade desconhecida'}, ${location.region || 'Região desconhecida'}, ${location.country || 'País desconhecido'}`;
        }

        // 1. Trocar o código por um token de acesso
        const tokenParams = new URLSearchParams();
        tokenParams.append('client_id', client_id);
        tokenParams.append('client_secret', client_secret);
        tokenParams.append('grant_type', 'authorization_code');
        tokenParams.append('code', code);
        tokenParams.append('redirect_uri', redirect_uri);
        tokenParams.append('scope', 'identify email guilds.members.read');

        const tokenResponse = await axios.post(
            'https://discord.com/api/oauth2/token',
            tokenParams,
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );

        const tokenData = tokenResponse.data;

        // 2. Obter dados do usuário
        const userResponse = await axios.get('https://discord.com/api/users/@me', {
            headers: {
                authorization: `${tokenData.token_type} ${tokenData.access_token}`,
            },
        });

        const user = userResponse.data;
        const userId = user.id;

        // 3. Armazenar refresh token
        await db.set(userId, tokenData.refresh_token);

        // 4. Adicionar cargo ao usuário
        const logChannel = client.channels.cache.get(canal_logs);
        if (!logChannel) {
            throw new Error("Canal de logs não encontrado");
        }

        const guild = logChannel.guild;
        const member = await guild.members.fetch(userId).catch(() => null);

        if (!member) {
            throw new Error("Usuário não encontrado no servidor");
        }

        const verificationRole = guild.roles.cache.get(cargo_verificado);
        if (verificationRole) {
            await member.roles.add(verificationRole);
            console.log(`[VERIFICAÇÃO] Cargo ${verificationRole.name} adicionado para ${member.user.tag}`);
        } else {
            console.log(`[AVISO] Cargo de verificação não encontrado`);
        }

        // 5. Enviar embed de log
        const verificationEmbed = new EmbedBuilder()
            .setTitle("✅ Verificação Concluída")
            .setColor("#00FF00")
            .setDescription(`**${member.user.tag}** foi verificado com sucesso!`)
            .addFields(
                { name: "👤 Usuário", value: `${member} (\`${userId}\`)`, inline: true },
                { name: "📧 Email", value: user.email || "Não disponível", inline: true },
                { name: "🌐 Localização", value: locationInfo, inline: false },
                { name: "📱 Dispositivo", value: parseUserAgent(req.headers['user-agent']), inline: false },
                { name: "🕒 Horário", value: new Date().toLocaleString("pt-BR"), inline: true }
            )
            .setThumbnail(member.user.displayAvatarURL())
            .setFooter({ text: `ID: ${userId} • IP: ${ip}` });

        await logChannel.send({ embeds: [verificationEmbed] });

        // 6. Responder com página de sucesso
        res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Verificação Concluída</title>
            <style>
                body {
                    font-family: 'Arial', sans-serif;
                    background-color: #36393f;
                    color: white;
                    text-align: center;
                    padding: 50px;
                }
                .success-box {
                    background-color: #2f3136;
                    border-radius: 8px;
                    padding: 30px;
                    max-width: 600px;
                    margin: 0 auto;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                }
                h1 {
                    color: #43b581;
                }
                .icon {
                    font-size: 60px;
                    margin-bottom: 20px;
                }
                .btn {
                    background-color: #5865f2;
                    color: white;
                    padding: 12px 25px;
                    border: none;
                    border-radius: 4px;
                    font-size: 16px;
                    cursor: pointer;
                    margin-top: 20px;
                    text-decoration: none;
                    display: inline-block;
                }
            </style>
        </head>
        <body>
            <div class="success-box">
                <div class="icon">✓</div>
                <h1>Verificação Concluída!</h1>
                <p>Você foi verificado com sucesso no servidor <strong>${guild.name}</strong>.</p>
                <p>Agora você tem acesso a todos os canais liberados para membros verificados.</p>
                <a href="https://discord.com/channels/${guild.id}" class="btn">Voltar ao Servidor</a>
            </div>
        </body>
        </html>
        `);

    } catch (error) {
        console.error("[ERRO] Falha no processo de verificação:", error);
        res.status(500).send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Erro na Verificação</title>
            <style>
                body {
                    font-family: 'Arial', sans-serif;
                    background-color: #36393f;
                    color: white;
                    text-align: center;
                    padding: 50px;
                }
                .error-box {
                    background-color: #2f3136;
                    border-radius: 8px;
                    padding: 30px;
                    max-width: 600px;
                    margin: 0 auto;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                }
                h1 {
                    color: #f04747;
                }
                .icon {
                    font-size: 60px;
                    margin-bottom: 20px;
                }
                .btn {
                    background-color: #5865f2;
                    color: white;
                    padding: 12px 25px;
                    border: none;
                    border-radius: 4px;
                    font-size: 16px;
                    cursor: pointer;
                    margin-top: 20px;
                    text-decoration: none;
                    display: inline-block;
                }
            </style>
        </head>
        <body>
            <div class="error-box">
                <div class="icon">✗</div>
                <h1>Falha na Verificação</h1>
                <p>Não foi possível completar seu processo de verificação.</p>
                <p>Por favor, entre em contato com a equipe do servidor para assistência.</p>
                <p><small>${error.message}</small></p>
                <a href="https://discord.com" class="btn">Voltar ao Discord</a>
            </div>
        </body>
        </html>
        `);
    }
});

// Função para analisar o User-Agent
function parseUserAgent(userAgent) {
    if (!userAgent) return "Dispositivo desconhecido";
    
    const deviceTypes = {
        "Windows NT": "Windows",
        "Macintosh": "Mac",
        "Linux": "Linux",
        "iPhone": "iPhone",
        "iPad": "iPad",
        "Android": "Android"
    };

    const browserTypes = {
        "Chrome": "Chrome",
        "Firefox": "Firefox",
        "Safari": "Safari",
        "Edge": "Edge",
        "Opera": "Opera",
        "MSIE": "Internet Explorer",
        "Trident": "Internet Explorer"
    };

    let os = "Sistema Operacional desconhecido";
    let browser = "Navegador desconhecido";

    for (const [key, value] of Object.entries(deviceTypes)) {
        if (userAgent.includes(key)) {
            os = value;
            break;
        }
    }

    for (const [key, value] of Object.entries(browserTypes)) {
        if (userAgent.includes(key)) {
            browser = value;
            break;
        }
    }

    return `${os} | ${browser}`;
}

module.exports = app;